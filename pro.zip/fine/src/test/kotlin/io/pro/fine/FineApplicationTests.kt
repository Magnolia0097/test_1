package io.pro.fine

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FineApplicationTests {

	@Test
	fun contextLoads() {
	}

}
